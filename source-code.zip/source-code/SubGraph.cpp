// #include "MSearcher.h"
// signed main(int argc, char *argv[]) {
// 	SubSearcher *subgraph = new SubSearcher(); 
// 	subgraph->read("./data/C125.9.bin"); subgraph->search();
// 	subgraph->read("./data/jazz.bin"); subgraph->search();
// 	subgraph->read("./data/sc-pkustk11.bin"); subgraph->search();
// 	subgraph->read("./data/consph.bin"); subgraph->search();
// 	subgraph->read("./data/soc-slashdot.bin"); subgraph->search();
// 	subgraph->read("./data/soc-youtube.bin"); subgraph->search();
// 	delete subgraph;
// }