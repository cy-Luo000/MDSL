#include "Graph.h"
int main(int argc, char *argv[]) {
	puts("\n-----------------------------------------------------------------------------------------");
	Graph *graph = new Graph(argv[1], atoi(argv[2]));
	graph->read(); 
	graph->search(); 
	graph->write(); // delete graph;
	puts("-----------------------------------------------------------------------------------------\n");
}